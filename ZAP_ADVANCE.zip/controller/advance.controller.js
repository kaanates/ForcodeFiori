sap.ui.define([
	"advance/payment/tvf/com/controller/BaseController",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";
	var that;
	return Controller.extend("advance.payment.tvf.com.controller.advance", {

		onInit: function() {
			that = this;
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			this._oResourceBundle = this._oComponent.getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("advance").attachPatternMatched(this._onObjectMatched, this);
			that.setModel();
			this.initoModel();
		},
		initoModel: function() {
			var oModel = new sap.ui.model.json.JSONModel({
				Ad: {},
				WaersList: [{
					key: "TRY"
				}, {
					key: "USD"
				}, {
					key: "EUR"
				}, {
					key: "GBP"
				}]
			});
			this._oView.setModel(oModel, "oModel");
		},
		readEntitiySetData: function(obj) {
			var entitySet = "";
			for (var i = 0; i < obj.filter.length; i++) {
				if (entitySet === "") {
					entitySet = obj.entityset + "(" + obj.filter[i].filter + "=" + obj.filter[i].Value;
				} else {
					entitySet = entitySet + "," + obj.filter[i].filter + "=" + obj.filter[i].Value;
				}
			}
			entitySet = entitySet + ")";
			that.getView().getModel().read(entitySet, {
				success: function(oData) {
					obj.setData.forEach(function(val) {
						var value = that.lookUp(oData, val.field);
						if (value && value.length > 0) {
							that.getModel("oModel").setProperty(val.path, value);
						}
					});
					that.hideBusy();
				},
				error: function(err) {
					that.hideBusy();
					that.showPopupMsgFromResponseText(err.responseText);
				}
			});
		},
		checkFarkliKisi: function(){
			var FarkliKisi = that.getModel("oModel").getProperty("/Ad/FarkliKisi");
			if(!FarkliKisi){
				that.getAdvance(that.SurecId);
			}
		},
		lookUp: function(o, path) {
			return path.split(">").reduce(function(r, e) {
				return r[e];
			}, o);
		},
		changePernr: function() {
			var Pernr = that.getModel("oModel").getProperty("/Ad/Pernr");
			var Waers = that.getModel("oModel").getProperty("/Ad/Waers");

			that.getModel("oModel").setProperty("/Ad/Approver04Desc", "");
			that.getModel("oModel").setProperty("/Ad/Approver03Desc", "");
			that.getModel("oModel").setProperty("/Ad/Approver02Desc", "");
			that.getModel("oModel").setProperty("/Ad/Approver01Desc", "");

			that.readEntitiySetData({
				entityset: "/PernrDataSet",
				filter: [{
					filter: "Pernr",
					Value: "'" + Pernr + "'"
				}],
				setData: [{
					path: "/Ad/Bukrs",
					field: "Bukrs"
				}, {
					path: "/Ad/PerAdi",
					field: "Ename"
				}, {
					path: "/Ad/PerSirket",
					field: "Butxt"
				}, {
					path: "/Ad/PerDepartman",
					field: "OrgehDesc"
				}, {
					path: "/Ad/PerPozisyon",
					field: "PlansDesc"
				}, {
					path: "/Ad/KostlDesc",
					field: "KostlDesc"
				}, {
					path: "/Ad/Kostl",
					field: "Kostl"
				}, {
					path: "/Ad/Approver01Desc",
					field: "Hierdat>MudurAdi"
				}, {
					path: "/Ad/Approver02Desc",
					field: "Hierdat>DirektorAdi"
				}, {
					path: "/Ad/Approver03Desc",
					field: "Hierdat>GmyAdi"
				}, {
					path: "/Ad/Approver04Desc",
					field: "Hierdat>GmAdi"
				}]
			});
			that.readEntitiySetData({
				entityset: "/PernrSet",
				filter: [{
					filter: "Pernr",
					Value: "'" + Pernr + "'"
				}, {
					filter: "Waerk",
					Value: "'" + Waers + "'"
				}],
				setData: [{
					path: "/Ad/AvansBakiye",
					field: "AvansBakiye"
				}, {
					path: "/Ad/OnayBakiye",
					field: "OnayBekleyenAvans"
				}]
			});
			that.getModel("oModel").setProperty("/Ad/Item", []);
		},
		onValueRequestPernr: function(oEvent) {
			that.getValueHelp(that, {
				title: "Personel Seç",
				showListInit: true,
				entitySet: "/PernrSet",
				filtersField: ["Ename"],
				afterSelect: that.changePernr,
				updatePats: [{
					path: oEvent.getSource().getBindingPath("value"),
					selValue: "Pernr"
				}, {
					path: "/Ad/Bukrs",
					selValue: "Bukrs"
				}],
				listTitles: [{
					col: "Pernr",
					text: "Sicil"
				}, {
					col: "Ename",
					text: "Adı"
				}, {
					col: "Bukrs",
					text: "Şirket Kodu"
				}]
			});
		},
		onValueRequestPspnr: function(oEvent) {
			that.getValueHelp(that, {
				title: "Proje Seçmek için Entere Basınız",
				entitySet: "/ProjectsSet",
				filtersField: ["Poski", "Postu"],
				updatePats: [{
					path: oEvent.getSource().getBindingPath("value"),
					selValue: "Poski"
				}, {
					path: "/Ad/PspnrDesc",
					selValue: "Postu"
				}],
				listTitles: [{
					col: "Postu",
					text: "Tanım"
				}, {
					col: "Poski",
					text: "Kısa tanıtıcı"
				}, {
					col: "Pspnr",
					text: "PYP dahili tn."
				}]
			});
		},
		_onObjectMatched: function(oEvent) {
			this.SurecId = oEvent.getParameter("arguments").SurecId;
			that.byId("ObjectPageLayout").scrollToSection(that.byId("ObjectPageLayout").getSections()[0].getId());
			that.getModel("oModel").setProperty("/Ad/Item", {});
			this.getAdvance(this.SurecId);
		},
		onLinePernrGetValue: function(oEvent) {
			var Pernrpath = oEvent.getSource().getBinding("value").getContext().getPath() + "/" + oEvent.getSource().getBindingPath(
				"value");
			var PerAdipath = Pernrpath.replace("Pernr", "PerAdi");
			var PerDepartmanpath = Pernrpath.replace("Pernr", "PerDepartman");
			var PerPozisyonpath = Pernrpath.replace("Pernr", "PerPozisyon");

			that.getValueHelp(that, {
				showListInit: true,
				title: "Personel Seç",
				entitySet: "/PernrSet",
				filtersField: ["Ename"],
				updatePats: [{
					path: Pernrpath,
					selValue: "Pernr"
				}, {
					path: PerAdipath,
					selValue: "Ename"
				}, {
					path: PerDepartmanpath,
					selValue: "PerDepartman"
				}, {
					path: PerPozisyonpath,
					selValue: "PerPozisyon"
				}],
				listTitles: [{
					col: "Pernr",
					text: "Sicil"
				}, {
					col: "Ename",
					text: "Adı"
				}, {
					col: "Bukrs",
					text: "Şirket Kodu"
				}, {
					col: "OrgehDesc",
					text: "Organizasyon"
				}, {
					col: "PlansDesc",
					text: "Pozisyon"
				}]
			});
		},

		getAdvance: function(SurecId) {
			var oModel = that.getView().getModel();
			var filters = [];
			var filterSurecId = new sap.ui.model.Filter("SurecId", sap.ui.model.FilterOperator.EQ, SurecId);
			filters.push(filterSurecId);

			that.showBusy();
			oModel.read("/AdvanceSet", {
				filters: filters,
				success: function(oData) {
					if (oData.results.length > 0) {
						if (oData.results[0].Akind ===""){
							oData.results[0].Akind = "01";
						}
						that._getViewModel("oModel").setProperty("/Ad", oData.results[0]);
					}
					that.hideBusy();
				},
				error: function(err) {
					that.hideBusy();
					that.showPopupMsgFromResponseText(err.responseText);
				}
			});
		},
		onSeyahatIdGetValue: function(oEvent) {
			var SeyahatIdpath = "/Ad/SeyahatId";
			var Bukrs = that.getModel("oModel").getProperty("/Ad/Bukrs");
			var Pernr = that.getModel("oModel").getProperty("/Ad/Pernr");
			var Gjahr = that.getModel("oModel").getProperty("/Ad/Gjahr");
			that.getValueHelp(that, {
				showListInit: true,
				title: "Seyahat Seç",
				defaultFilter: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, Pernr)
				],
				entitySet: "/SeyahatListSet",
				filtersField: [],
				updatePats: [{
					path: SeyahatIdpath,
					selValue: "SurecId"
				}],
				listTitles: [{
					col: "SurecId",
					text: "Seyahat ID"
				}, {
					col: "Bukrs",
					text: "Ş.Kodu"
				}, {
					col: "Gjahr",
					text: "Yıl"
				}, {
					col: "Pernr",
					text: "Sicil"
				}, {
					col: "Yer",
					text: "Yer"
				}, {
					col: "GidisTarihi",
					text: "GidisTarihi"
				}]
			});
		},
		saveAction: function(action) {
			var Ad = that.getModel("oModel").getProperty("/Ad");
			if (Ad) {
				that.showBusy();
				var exData = {};
				var oEntry = {};
				that.moveCorresponding(Ad, exData);
				oEntry.SurecId = exData.SurecId;
				oEntry.Process = action === "" ? exData.SurecId === "$000000001" ? "CREATE" : "UPDATE" : action;
				oEntry.Ad = [exData];
				oEntry.Return = [];

				var oDataModel = that.getView().getModel();
				oDataModel.create("/AdvanceSaveSet", oEntry, {
					success: function(oDataResponse) {
						that.hideBusy();
						if (oDataResponse && oDataResponse.Return) {
							var messageObject = that.getODataReturnMessageObject(oDataResponse.Return);
							var Err = messageObject.IsError;
							if (exData.SurecId === "$000000001" && Err !== true) {
								if (oDataResponse.Return.results[0].Type === "S" && oDataResponse.Return.results[0].Id === "ZFI_020_MSG01") {

								}
							}
							that.showODataReturnMessageList(messageObject, function() {
								if (Err !== true) {
									that.handleNavBack();
								}
							});
						} else {
							that.showErrorMessageDialog("", that.getResourceBundle().getText("errorText"));
						}
					},
					error: function(oDataError) {
						that.hideBusy();
						that.showPopupMsgFromResponseText(oDataError.responseText);
					}
				});
			}

		},
		onSaveButton: function(e) {
			that.saveAction("");
		},
		onDeleteButton: function(e) {
			MessageBox.confirm(this.SurecId + " nolu Avans kaydını silmek istiyormusunuz?", {
				title: "Kayıt Silme",
				onClose: function(action) {
					if (action === "OK") {
						that.saveAction("DELETE");
					}
				}
			});
		},
		onUploadComplete: function(e) {
			this.getAttachments(this.SurecId);
		},
		beforeFileDelete: function(e) {
			var filename = e.getParameter("item").getFileName();

			that.oModel.remove("/AttachmentsSet(DocId='" + filename + "')", {
				method: "DELETE",
				success: function(data) {
					this.getAttachments(this.SurecId);
				},
				error: function(e) {}
			});

		},
		onUCChange: function(e) {
			var oUploadSet = e.getSource();
			oUploadSet.destroyHeaderFields();
			var SurecId = that.SurecId;
			var token = that.getModel().getSecurityToken();
			oUploadSet.addHeaderField(new sap.ui.core.Item({
				key: "x-csrf-token",
				text: token
			}));

			oUploadSet.addHeaderField(new sap.ui.core.Item({
				key: "slug",
				text: SurecId + "|" + encodeURIComponent(e.getParameter("item").getFileName())
			}));
			oUploadSet.addHeaderField(new sap.ui.core.Item({
				key: "content-disposition",
				text: "attachment; filename=\"" + encodeURIComponent(e.getParameter("item").getFileName()) + "\""
			}));
		},

	});

});