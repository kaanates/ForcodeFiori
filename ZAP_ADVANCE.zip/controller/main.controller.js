sap.ui.define([
	"advance/payment/tvf/com/controller/BaseController"
], function(Controller) {
	"use strict";
	var that;
	return Controller.extend("advance.payment.tvf.com.controller.main", {

		onInit: function(e) {
			that = this;
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			this._oResourceBundle = this._oComponent.getModel("i18n").getResourceBundle();
			this.setModel();
			this.getRouter().getRoute("main").attachPatternMatched(this.getTableData, this);
			this.initoModel();
		},
		initoModel: function() {
			var oModel = new sap.ui.model.json.JSONModel({
				AdvanceList: [],
				Bukrs: "",
				Budat1: "",
				Budat2: "",
				Pspnr: "",
				Statu: "",
				desktop: sap.ui.Device.system.desktop,
				BukrsList: [],
				StatuList: [{
					key: "",
					text: "Tümü"
				}, {
					key: "INPROCESS",
					text: "İşlemde"
				}, {
					key: "WAIT",
					text: "Onay sürecinde"
				}, {
					key: "COMPLETED",
					text: "Tamamlandı"
				}, {
					key: "REJECTED",
					text: "Reddedildi"
				}]
			});
			this._oView.setModel(oModel, "oModel");
		},
		initTable: function(r) {
			var oModel = this._oView.getModel();
			r.showBusy();
			var aFilter = [];
/*			var Bukrs = that.getModel("oModel").getProperty("Bukrs");
			if (Bukrs !== "") {
				var oFilterBukrs = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, Bukrs);
				aFilter.push(oFilterBukrs);
			}*/

			var Budat1 = that.getModel("oModel").getProperty("/Budat1");
			var Budat2 = that.getModel("oModel").getProperty("/Budat2");
			if (Budat1 !== "" && Budat1 !== undefined && Budat1 !== null ) {
				var eq = sap.ui.model.FilterOperator.EQ;
				if(Budat2!=="" && Budat2 !== undefined && Budat2 !== null) {
					eq = sap.ui.model.FilterOperator.BT;
				}
				var oFilterBudat = new sap.ui.model.Filter("Bldat", eq, Budat1, Budat2);
				aFilter.push(oFilterBudat);
			}
			var Pspnr = that.getModel("oModel").getProperty("/Pspnr");
			if (Pspnr !== ""  && Pspnr !== undefined && Pspnr !== null) {
				var oFilterPspnr = new sap.ui.model.Filter("Pspnrd", sap.ui.model.FilterOperator.EQ, Pspnr);
				aFilter.push(oFilterPspnr);
			}
			var Statu = that.getModel("oModel").getProperty("/Statu");
			if (Statu !== "" && Statu !== undefined && Statu !== null) {
				var oFilterDurum = new sap.ui.model.Filter("Statu", sap.ui.model.FilterOperator.EQ, Statu);
				aFilter.push(oFilterDurum);
			}
			oModel.read("/AdvanceSet", {
				filters: aFilter,
				success: function(oData) {
					r._setViewModelProperty("oModel", "AdvanceList", oData.results);
					r.hideBusy();
					if (r.byId("pullToRefresh")) {
						r.byId("pullToRefresh").hide();
					}
				},
				error: function(e) {
					r.hideBusy();
					that.showPopupMsgFromResponseText(e.responseText);
				}
			});

		},
		onValueRequestPspnr: function(oEvent) {
			that.getValueHelp(that, {
				title: "Proje Seçmek için Entere Basınız",
				entitySet: "/ProjectsSet",
				filtersField: ["Poski", "Postu"],
				updatePats: [{
					path: oEvent.getSource().getBindingPath("value"),
					selValue: "Poski"
				}],
				listTitles: [{
					col: "Postu",
					text: "Tanım"
				}, {
					col: "Poski",
					text: "Kısa tanıtıcı"
				}, {
					col: "Pspnr",
					text: "PYP dahili tn."
				}]
			});
		},
		handleRefresh: function() {
			this.initTable(this);
		},
		onGetAdvanceForm: function(e) {
			var line = e.getSource().getBindingContext("oModel").getObject();
			var url = "/sap/opu/odata/sap/ZFR_APP_SRV/AttachmentsSet(DocID='" +	line.SurecId + "^" + "masrafformu" + "')/$value";
			var oA = document.createElement("a");
			oA.href = url;
			oA.target = "_blank";
			oA.style.display = "none";
			document.body.appendChild(oA);
			oA.click();
			document.body.removeChild(oA);
		},
		getDefList: function(e) {
			var oModel = that.getView().getModel();
			that.showBusy();
			var filters = [];
			var filterBukrs = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.BT, "1000", "9000");
			filters.push(filterBukrs);
			oModel.read("/BukrsListSet", {
				filters: filters,
				success: function(oData) {
					that._getViewModel("oModel").setProperty("/BukrsList", oData.results);
					that.hideBusy();
				},
				error: function(err) {
					that.hideBusy();
					that.showPopupMsgFromResponseText(err.responseText);
				}
			});
		},
		getTableData: function() {
			this.initTable(this);
			that.getDefList();
		},
		onItemPress: function(e) {
			var line = e.getSource().getBindingContext("oModel").getProperty(e.getSource().getBindingContextPath());
			this._oComponent.getRouter().navTo("advance", {
				SurecId: line.SurecId
			}, false);

		},
		onNewAdvance: function(e) {
			this._oComponent.getRouter().navTo("advance", {
				SurecId: "$"
			}, false);
		},
		excelExport: function(e) {
			this.JSONToCSVConvertor("Mağazadan Gönderilen Sipaerişler", true, "cs005Select");
		},

	});

});